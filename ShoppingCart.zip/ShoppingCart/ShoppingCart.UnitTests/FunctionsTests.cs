﻿using System;
using NUnit.Framework;
using ShoppingCart;

namespace ShoppingCart.UnitTests
{
    [TestFixture]
    public class FunctionsTests
    {
        [Test]
        public void Should()
        {
            var sut = new Functions();

        }
    }
}
