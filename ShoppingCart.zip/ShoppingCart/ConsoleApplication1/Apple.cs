﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    public class Apple : Fruit
    {
        public Apple()
            :base(1,"Apple",100,0.65)
        {
        }
    }
}
