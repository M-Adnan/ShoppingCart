﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    public class Functions
    {
        Fruit apple;
        Fruit orange;

        public Functions()
        {
            apple = new Apple();
            orange = new Orange();
        }
        

        public int CaptureValidateInput(string msg)
        {
            int number;

            while (!int.TryParse(Console.ReadLine(), out number))
            {
                Console.WriteLine("\nsorry I don't recognise this input.");
                Console.WriteLine(msg);
                Console.Write("Please enter a valid input:");
            }

            return number;
        }

        private bool ValidateQuantityInput(int input, int lowerLimit, int upperLimit)
        {
            if (input < lowerLimit || input > upperLimit)
            {
                Console.Write("\nEntered quanity isn't within the specified limit.\nPleae enter a quantity between 1 to 100:");
                return false;
            }
            return true;
        }

        private void ShowBasketMsg(Fruit fruit)
        {
            Console.Write(string.Format("\nYou have selected {0} {1}(s) for the price of {2} pounds per {1}.",fruit.Quantity,fruit.name,Math.Round(fruit.Price,2)));
            Console.Write(string.Format("\nTotal price for selected {0}s: {1} pounds", fruit.name,Math.Round(fruit.CalculateTotal(),2)));
        }

        private int CaptureValidateQuantity(Fruit fruit)
        {
            int input;
            Console.Write(string.Format("You can only purchase max of 100 {0}s at a time.",fruit.name));
            Console.Write(string.Format("\nPlease enter quanitity for {0}s:", fruit.name));
            do
            {
                input = CaptureValidateInput("\nPleae enter a quantity between 1 to 100.\nMax of 100 items of the same product can be purchased at a time.");
            }
            while (!(ValidateQuantityInput(input, 1, 100)));
            return input;
        }

        internal bool ContinueorCheckout()
        {
            bool validInput = false;
            bool continueShopping = false;

            Console.Write("\n\nWould you like to continue shopping (Y/N):");
            string continueorCheckout = Console.ReadLine();
            do // or some other condition
            {
                if (continueorCheckout == "Y" || continueorCheckout == "y")
                {
                    validInput = true;
                    continueShopping = true;
                }
                else if (continueorCheckout == "N" || continueorCheckout == "n")
                {
                    validInput = true;
                    continueShopping = false;
                    Console.WriteLine("\nThanks you for shopping with GAIN.");
                    ShowBasketMsg(apple);
                    ShowBasketMsg(orange);
                    CalculateBasketTotal();                   
                }
                else
                {
                    continueShopping = false;
                    validInput = false;
                    Console.Write("\nsorry I don't recognise this input. \nPlease enter a valid option. Your options are... \n\r1. Y or y to continue shopping\n\r2. N or n to checkout");
                    Console.Write("\nWould you like to continue shopping (Y/N):");
                    continueorCheckout = Console.ReadLine();
                }
            } while (!validInput);

            return continueShopping;
        }

        private void CalculateBasketTotal()
        {
            Console.Write(string.Format("\nTotal price of your shopping is: {0} pounds", Math.Round(apple.CalculateTotal(),3)+Math.Round(orange.CalculateTotal(),3)));
        }

        internal void GetProductAndQuantity()
        {
            Console.Write("\n\rPlease select your product: ");
            int input = CaptureValidateInput("\nPlease enter a valid option from the following products\n\r1. Apples \n\r2. Oranges");
            do
            {
                if (input == 1)
                {
                    int qyt = CaptureValidateQuantity(apple);
                    apple.Quantity = qyt;
                    break;
                }
                else if (input == 2)
                {
                    int qyt = CaptureValidateQuantity(orange);
                    orange.Quantity = qyt;
                    break;
                }
                else
                {
                    Console.Write("\nsorry I don't recognise this input. \nPlease enter a valid option from the following products\n\r1. Apples \n\r2. Oranges");
                    Console.Write("\nPlease enter a valid option:");
                    input = CaptureValidateInput("\nPlease enter a valid option from the following products\n\r1. Apples \n\r2. Oranges");
                }
            } while (input != 1 || input != 2);
        }
    }
}
