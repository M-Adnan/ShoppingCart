﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    public class Fruit : Product
    {
        public string name { get; set; }        

        public Fruit(int productCode, string name, int upperLimit, double price)
            :base(productCode, price)
        {
            
            this.name = name;
            this.upperLimit = upperLimit;
        }

        public double CalculateTotal()
        {
            return (this.Price * this.Quantity);
        }
    }
}
