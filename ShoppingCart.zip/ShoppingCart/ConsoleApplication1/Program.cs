﻿using System;
using System.IO;


namespace ShoppingCart
{
    public class Program
    {
        public static void Main(string[] args)
        {

            Functions fn = new Functions();

            bool continueShopping = true;
            
            Console.WriteLine("***Welcome to the GAIN shopping cart***\n\n\rFollowing two products are available for shopping \n\r1. Apples \n\r2. Oranges");
            
            while(continueShopping)
            {

                fn.GetProductAndQuantity();
                
                continueShopping = fn.ContinueorCheckout();
            }
            
            Console.Write("\n\nPlease press enter to exit...");
            Console.Read();
        }
    }
}
