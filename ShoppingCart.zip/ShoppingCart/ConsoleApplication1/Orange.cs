﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    public class Orange : Fruit
    {
        public Orange()
            :base(2,"Orange",100, 0.25)
        {
        }
    }
}
