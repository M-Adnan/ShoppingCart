﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    public class Product
    {
        internal int upperLimit;
        private int productCode { get; set; }
        private double price;
        public double Price
        {
            get
            {
                return this.price;
            }
        }

        public Product(int productCode, double price)
        {
            this.productCode = productCode;
            this.price = price;
        }

        private int quantity;

        public int Quantity
        {
            get
            {
                return this.quantity;
            }

            set
            {
                int temp1 = value;
                int temp2 = this.quantity + temp1;
                if (temp2 > upperLimit)
                {
                    Console.Write(string.Format("\nSorry the quantity has crossed the max specified limit of {0}", upperLimit));
                }
                else
                {
                    this.quantity += temp1;               
                }
            }
        }
    }
}
