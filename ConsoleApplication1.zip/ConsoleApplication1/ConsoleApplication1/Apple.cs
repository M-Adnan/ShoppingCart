﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Apple : Fruit
    {
        private double price { get; set; }
        public Apple()
            :base(1,"Apple")
        {
            this.price = 0.60;
        }
    }
}
