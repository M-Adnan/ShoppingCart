﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Functions
    {
        public static int CaptureInput()
        {
            int number;

            while (!int.TryParse(Console.ReadLine(), out number))
            {
                Console.WriteLine("\nsorry I don't recognise this input. \nPlease enter a valid option from the following products\n\r1. Apples \n\r2. Oranges");
                Console.Write("Please enter a valid option:");
            }

            return number;
        }
    }
}
