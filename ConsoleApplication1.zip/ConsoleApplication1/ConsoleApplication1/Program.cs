﻿using System;
using System.IO;


namespace ConsoleApplication1
{
    public class Program
    {
        public static void Main(string[] args)
        {

            Orange O = new Orange();
            O.quantity = 1;

            Console.WriteLine(O.quantity);

            /*int productOption;
            //Console.WriteLine("Please enter the product option");
            do
            {
                Console.WriteLine("Please enter the product option");
                productOption = Convert.ToInt32(Console.ReadLine());
            } while (productOption != 1 || productOption != 2);*/
         
        }
    }
}
