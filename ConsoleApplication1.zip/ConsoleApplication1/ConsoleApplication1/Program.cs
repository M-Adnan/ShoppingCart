﻿using System;
using System.IO;


namespace ConsoleApplication1
{
    public class Program
    {
        public static void Main(string[] args)
        {

            Console.WriteLine("***Welcome to the GAIN shopping cart***\n\n\rFollowing two products are available for shopping \n\r1. Apples \n\r2. Oranges");
            Console.Write("\n\rPlease select your product: ");

            int input = Functions.CaptureInput();

            while (input!= 1 || input != 2) // or some other condition
            {
                if (input == 1)
                {
                    Console.WriteLine("Apple");
                    break;
                }
                else if (input == 2)
                {
                    Console.WriteLine("Oranges");
                    break;
                }
                else
                {
                    Console.Write("\nsorry I don't recognise this input. \nPlease enter a valid option from the following products\n\r1. Apples \n\r2. Oranges");
                    Console.Write("\nPlease enter a valid option:");
                    input = Functions.CaptureInput(); // again
                }
            }

            Console.ReadLine();
            /*Console.WriteLine("***Welcome to the GAIN shopping cart***\n\n\rFollowing two products are available for shopping \n\r1. Apples \n\r2. Oranges");
            Console.Write("\n\rPlease select your product: ");

            string line = Console.ReadLine();
            int value;
            if (int.TryParse(line, out value))
            {
                // this is an int
                // do you minimum number check here
            }
            else
            {
                // this is not an int
            }
            /*do
            {
                Console.WriteLine("Please enter the product option");
                productOption = Convert.ToInt32(Console.ReadLine());
            } while (productOption != 1 || productOption != 2);*/
         
        }
    }
}
