﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Orange : Fruit
    {
        private double price { get; set; }
        public int quantity {
            get
            {
                return this.quantity;
            }
            set
            {
                this.quantity = value;
            }
        }

        public Orange()
            :base(2,"Orange")
        {
            this.price = 0.25;
        }
    }
}
